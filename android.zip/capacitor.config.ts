import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.glenmark.breathefreshma',
  appName: 'BYE-LERGY',
  webDir: 'www'
};

export default config;
