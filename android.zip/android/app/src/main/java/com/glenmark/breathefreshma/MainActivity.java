package com.glenmark.breathefreshma;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
