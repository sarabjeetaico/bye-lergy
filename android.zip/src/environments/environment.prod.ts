export const environment = {
  production: true,
  apiUrl:"https://multipliersolutions.in/glenmark_malaysia_api/",
  AQIURL:"http://api.airvisual.com/v2/nearest_city",
  apikey:"2fd7bb50-a971-4ea2-bc98-d46d26879d5e",
  // apikey:"dd0dabd5451d4502b3e121235211712",
  TempURL:"http://api.weatherapi.com/v1/current.json",
  // pollenURL:"https://api.tomorrow.io/v4/timelines?fields=treeIndex,weedIndex,grassIndex&timesteps=current&apikey=rC4oqYopmmYyPvujHWwtPYLXl4ocgAMu&"
  pollenURL: 'https://api.ambeedata.com/latest/pollen/by-lat-lng?',
  newApi : "https://api.ambeedata.com/latest/by-lat-lng?", 
  newApiKey : "12c8587eb130d5c95e5fae273eaef821a5b711ac5463a841086138405b9a4017",
  googleMapsApiKey: "AIzaSyD9f4YAdvMNPa6HSPSkd3K7uYM4ZxecKjw"
};
